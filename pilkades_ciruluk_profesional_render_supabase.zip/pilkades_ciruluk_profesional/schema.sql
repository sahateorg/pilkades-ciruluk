CREATE TABLE IF NOT EXISTS candidates (
  id SERIAL PRIMARY KEY,
  candidate_number INTEGER NOT NULL UNIQUE,
  name TEXT NOT NULL,
  photo_url TEXT,
  active BOOLEAN NOT NULL DEFAULT TRUE
);

-- Tabel ini menyimpan token/identitas peserta dan status pemakaian.
-- Tidak ada foreign key atau participant_id di tabel ballots.
CREATE TABLE IF NOT EXISTS qr_tokens (
  id BIGSERIAL PRIMARY KEY,
  token_hash CHAR(64) NOT NULL UNIQUE,
  participant_label TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  used_at TIMESTAMPTZ
);

-- Tabel suara anonim: tidak menyimpan token, nama, atau ID peserta.
CREATE TABLE IF NOT EXISTS ballots (
  id BIGSERIAL PRIMARY KEY,
  candidate_number INTEGER NOT NULL,
  cast_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

INSERT INTO candidates(candidate_number, name, photo_url)
VALUES
 (1, 'Nama Kandidat 1', NULL),
 (2, 'Nama Kandidat 2', NULL),
 (3, 'TETEN SETIAWAN', '/kandidat-3.jpg')
ON CONFLICT (candidate_number) DO NOTHING;

INSERT INTO app_settings(key, value)
VALUES ('voting_open', 'true')
ON CONFLICT (key) DO NOTHING;
