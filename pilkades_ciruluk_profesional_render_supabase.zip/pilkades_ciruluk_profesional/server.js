require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { Pool } = require("pg");
const crypto = require("crypto");
const path = require("path");

const required = ["DATABASE_URL", "ADMIN_PASSWORD", "ADMIN_API_KEY"];
for (const key of required) {
  if (!process.env[key]) {
    console.error(`Konfigurasi ${key} belum diisi. Salin .env.example menjadi .env.`);
    process.exit(1);
  }
}
if (process.env.ADMIN_API_KEY.length < 32) {
  console.error("ADMIN_API_KEY harus minimal 32 karakter.");
  process.exit(1);
}

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL.includes("localhost") ? false : { rejectUnauthorized: false }
});
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "50kb" }));
app.use(express.static(path.join(__dirname, "public")));

const adminLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false });
const voteLimiter = rateLimit({ windowMs: 10 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false });

function adminOnly(req, res, next) {
  const supplied = req.get("x-admin-key") || "";
  const a = Buffer.from(supplied);
  const b = Buffer.from(process.env.ADMIN_API_KEY);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Akses admin ditolak." });
  }
  next();
}
function hashToken(token) {
  return crypto.createHash("sha256").update(token).digest("hex");
}
async function initDb() {
  const fs = require("fs");
  const sql = fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8");
  await pool.query(sql);
}
app.get("/api/health", async (_req, res) => {
  try { await pool.query("SELECT 1"); res.json({ ok: true }); }
  catch { res.status(503).json({ ok: false }); }
});

app.post("/api/admin/login", adminLimiter, (req, res) => {
  const password = String(req.body.password || "");
  const a = Buffer.from(password);
  const b = Buffer.from(process.env.ADMIN_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Password admin salah." });
  }
  res.json({ ok: true, adminKey: process.env.ADMIN_API_KEY });
});

app.get("/api/candidates", async (_req, res) => {
  const { rows } = await pool.query(
    "SELECT candidate_number, name, photo_url FROM candidates WHERE active=TRUE ORDER BY candidate_number"
  );
  res.json(rows);
});

app.get("/api/voting-status", async (_req, res) => {
  const { rows } = await pool.query("SELECT value FROM app_settings WHERE key='voting_open'");
  res.json({ open: rows[0]?.value === "true" });
});

app.post("/api/qr/validate", voteLimiter, async (req, res) => {
  const token = String(req.body.token || "").trim();
  if (token.length < 20 || token.length > 200) return res.status(400).json({ error: "QR Code tidak valid." });
  const { rows: setting } = await pool.query("SELECT value FROM app_settings WHERE key='voting_open'");
  if (setting[0]?.value !== "true") return res.status(403).json({ error: "Simulasi pemilihan sedang ditutup." });
  const { rows } = await pool.query(
    "SELECT id FROM qr_tokens WHERE token_hash=$1 AND used_at IS NULL",
    [hashToken(token)]
  );
  if (!rows.length) return res.status(409).json({ error: "QR Code tidak dikenal atau sudah digunakan." });
  res.json({ valid: true });
});

app.post("/api/vote", voteLimiter, async (req, res) => {
  const token = String(req.body.token || "").trim();
  const candidateNumber = Number(req.body.candidateNumber);
  if (token.length < 20 || token.length > 200 || !Number.isInteger(candidateNumber)) {
    return res.status(400).json({ error: "Data pilihan tidak valid." });
  }
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows: setting } = await client.query("SELECT value FROM app_settings WHERE key='voting_open' FOR SHARE");
    if (setting[0]?.value !== "true") {
      await client.query("ROLLBACK");
      return res.status(403).json({ error: "Simulasi pemilihan sedang ditutup." });
    }
    const { rows: candidate } = await client.query(
      "SELECT candidate_number FROM candidates WHERE candidate_number=$1 AND active=TRUE",
      [candidateNumber]
    );
    if (!candidate.length) {
      await client.query("ROLLBACK");
      return res.status(400).json({ error: "Kandidat tidak tersedia." });
    }
    const consumed = await client.query(
      "UPDATE qr_tokens SET used_at=NOW() WHERE token_hash=$1 AND used_at IS NULL RETURNING id",
      [hashToken(token)]
    );
    if (!consumed.rowCount) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "QR Code sudah digunakan atau tidak valid. Setiap QR hanya berlaku satu kali." });
    }
    // Sengaja tidak menyimpan ID/token peserta pada tabel ballots.
    await client.query("INSERT INTO ballots(candidate_number) VALUES($1)", [candidateNumber]);
    await client.query("COMMIT");
    res.json({ ok: true, message: "Pilihan anda sudah tersimpan. Terima Kasih." });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Vote transaction failed:", err.message);
    res.status(500).json({ error: "Terjadi kesalahan. Silakan hubungi petugas." });
  } finally {
    client.release();
  }
});

app.get("/api/admin/overview", adminLimiter, adminOnly, async (_req, res) => {
  const [participants, votes, results, status] = await Promise.all([
    pool.query("SELECT COUNT(*)::int total, COUNT(*) FILTER (WHERE used_at IS NOT NULL)::int used FROM qr_tokens"),
    pool.query("SELECT COUNT(*)::int total FROM ballots"),
    pool.query(`SELECT c.candidate_number, c.name, COUNT(b.id)::int votes
                FROM candidates c LEFT JOIN ballots b ON b.candidate_number=c.candidate_number
                WHERE c.active=TRUE GROUP BY c.candidate_number,c.name ORDER BY c.candidate_number`),
    pool.query("SELECT value FROM app_settings WHERE key='voting_open'")
  ]);
  res.json({
    participants: participants.rows[0],
    totalVotes: votes.rows[0].total,
    results: results.rows,
    votingOpen: status.rows[0]?.value === "true"
  });
});

app.post("/api/admin/qr-batch", adminLimiter, adminOnly, async (req, res) => {
  const count = Number(req.body.count);
  if (!Number.isInteger(count) || count < 1 || count > 100) {
    return res.status(400).json({ error: "Jumlah QR harus antara 1 sampai 100." });
  }
  const labels = Array.isArray(req.body.labels) ? req.body.labels : [];
  const client = await pool.connect();
  const created = [];
  try {
    await client.query("BEGIN");
    for (let i = 0; i < count; i++) {
      const token = crypto.randomBytes(24).toString("base64url");
      const label = String(labels[i] || `Peserta ${i + 1}`).slice(0, 100);
      await client.query("INSERT INTO qr_tokens(token_hash, participant_label) VALUES($1,$2)", [hashToken(token), label]);
      // Token mentah hanya dikembalikan sekali untuk dicetak admin.
      created.push({ label, token });
    }
    await client.query("COMMIT");
    res.json({ created });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("QR batch failed:", err.message);
    res.status(500).json({ error: "Gagal membuat QR Code." });
  } finally { client.release(); }
});

app.post("/api/admin/voting", adminLimiter, adminOnly, async (req, res) => {
  const open = Boolean(req.body.open);
  await pool.query(
    "INSERT INTO app_settings(key,value) VALUES('voting_open',$1) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value",
    [String(open)]
  );
  res.json({ ok: true, open });
});

app.get("/api/admin/participants", adminLimiter, adminOnly, async (_req, res) => {
  const { rows } = await pool.query(
    "SELECT participant_label, created_at, used_at FROM qr_tokens ORDER BY id"
  );
  res.json(rows);
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = Number(process.env.PORT || 3000);
initDb().then(() => app.listen(port, () => console.log(`Ciruluk demo berjalan di port ${port}`)))
  .catch(err => { console.error("Database initialization failed:", err); process.exit(1); });
