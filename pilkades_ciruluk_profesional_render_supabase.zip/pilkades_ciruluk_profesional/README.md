# Simulasi Pilkades Digital Desa Ciruluk

Aplikasi web prototipe full-stack untuk 100 peserta, pemindaian QR melalui kamera Android/tablet, QR sekali pakai, pilihan anonim, dan dashboard admin.

## Fitur
- Kamera belakang Android untuk scan QR.
- Surat suara 3 kandidat dan layar konfirmasi YA/TIDAK.
- QR peserta unik, disimpan dalam database sebagai hash; token mentah hanya ditampilkan saat batch dibuat.
- Token dikonsumsi satu kali saat suara disimpan.
- Tabel `ballots` tidak menyimpan token, identitas, maupun ID peserta.
- Dashboard admin: jumlah peserta, partisipasi, total suara, hasil per kandidat, status QR, buka/tutup simulasi.
- Cetak lembar QR untuk peserta.

## Menjalankan secara lokal
1. Instal Node.js 20+ dan PostgreSQL.
2. Buat database PostgreSQL.
3. Salin `.env.example` menjadi `.env`, lalu isi `DATABASE_URL`, `ADMIN_PASSWORD`, `ADMIN_API_KEY`.
4. Jalankan:
   ```bash
   npm install
   npm start
   ```
5. Buka `http://localhost:3000`. Untuk akses kamera dari perangkat lain, deploy melalui HTTPS.

Aplikasi membuat tabel dan kandidat awal secara otomatis dari `schema.sql`.

## Deploy Render + Supabase (pilihan yang direkomendasikan)
1. Buat project PostgreSQL di Supabase.
2. Di Supabase, buka **Connect** lalu pilih **Session pooler**. Salin URI koneksi PostgreSQL dan ganti placeholder password. Karena Render menjalankan backend Node yang persisten, direct connection juga dapat dipakai jika lingkungan mendukung IPv6; session pooler cocok bila perlu koneksi IPv4.
3. Unggah isi folder proyek ini ke repository GitHub baru. Jangan unggah `.env`.
4. Di Render pilih **New → Blueprint** bila ingin memakai `render.yaml`, atau **New → Web Service** lalu hubungkan repository.
5. Untuk Web Service manual: Runtime `Node`, Build Command `npm install`, Start Command `npm start`, Health Check Path `/api/health`.
6. Tambahkan environment variables `DATABASE_URL`, `ADMIN_PASSWORD`, dan `ADMIN_API_KEY` di Render. Gunakan password admin kuat dan API key acak minimal 32 karakter. Jangan kirim rahasia tersebut lewat chat.
7. Deploy. Setelah status Live, buka URL `https://...onrender.com` di HP Android dan izinkan kamera.
8. Buka menu Admin, login memakai `ADMIN_PASSWORD`, lalu buat 100 QR Code dan cetak.

`render.yaml` sudah disediakan untuk konfigurasi service dan health check. Nilai rahasia tetap harus dimasukkan di Render secara manual.

- Buat database PostgreSQL terkelola (mis. Neon/Supabase).
- Deploy folder proyek ini ke layanan Node.js (mis. Render/Railway).
- Set environment variables dari `.env.example` pada dashboard hosting.
- Set `APP_URL` ke URL HTTPS publik aplikasi.
- Jangan commit file `.env` ke Git.
- Buka URL HTTPS dari Android/tablet dan izinkan akses kamera.

## Mengubah data kandidat
Edit tabel `candidates` di PostgreSQL atau ubah nilai awal di `schema.sql`.
Letakkan foto kandidat di folder `public/` dan isi `photo_url`, misalnya `/kandidat-1.jpg`.
Foto kandidat nomor 3 dari poster awal disertakan sebagai `public/kandidat-3.jpg`. Foto nomor 1 dan 2 perlu diberikan untuk melengkapi tampilan.

## Membuat 100 QR peserta
Login sebagai admin → masukkan jumlah 100 → Buat QR Code → Cetak QR Code.
Simpan hasil cetak secara aman. Token QR mentah hanya ditampilkan pada saat batch dibuat; buat batch baru bila lembar QR hilang sebelum dibagikan.

## Keamanan dan batasan penting
Ini adalah prototipe simulasi, bukan perangkat pemungutan suara resmi. Jangan digunakan untuk menentukan hasil pemilihan yang sah.
- Gunakan HTTPS.
- Gunakan password admin dan API key yang kuat; jangan bagikan API key.
- Tabel suara tidak mengandung ID peserta, tetapi server tetap memproses token dan suara dalam satu transaksi. Sistem ini bukan jaminan anonimitas tingkat pemilu dan belum melalui audit keamanan independen.
- Admin key disimpan pada `sessionStorage` browser admin; logout dengan menutup tab browser atau menghapus sesi browser.
- Belum ada fitur backup otomatis, audit independen, pemulihan token, ekspor hasil resmi, atau manajemen kandidat melalui UI.
- QR sekali pakai mengurangi pemakaian ulang, tetapi aplikasi tetap perlu diuji dan diaudit sebelum penggunaan publik.
